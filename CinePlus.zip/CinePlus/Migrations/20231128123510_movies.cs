﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace CinePlus.Migrations
{
    /// <inheritdoc />
    public partial class movies : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Movies",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Poster = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Synopsis = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Director = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Genre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Movies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Rating",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Score = table.Column<int>(type: "int", nullable: false),
                    MovieId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rating", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Rating_Movies_MovieId",
                        column: x => x.MovieId,
                        principalTable: "Movies",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "Movies",
                columns: new[] { "Id", "Director", "Genre", "Poster", "Synopsis", "Title" },
                values: new object[,]
                {
                    { 1, "James Cameron", "SciFi", "Avatar_(2009_film)_poster.jpg", "Avatar (marketed as James Cameron's Avatar) is a 2009 epic science fiction film directed, written, co-produced, and co-edited by James Cameron and starring Sam Worthington, Zoe Saldana, Stephen Lang, Michelle Rodriguez,[6] and Sigourney Weaver.", "Avatar" },
                    { 2, "Russo Brothers", "SciFi", "Avengers_Endgame_poster.jpg", "Avengers: Endgame is a 2019 American superhero film based on the Marvel Comics superhero team the Avengers.", "Avengers: Endgame" },
                    { 3, "James Cameron", "SciFi", "Avatar_The_Way_of_Water_poster.jpg", "Avatar: The Way of Water is a 2022 American epic science fiction film co-produced and directed by James Cameron, who co-wrote the screenplay with Rick Jaffa and Amanda Silver from a story the trio wrote with Josh Friedman and Shane Salerno.", "Avatar: The Way of Water" },
                    { 4, "James Cameron", "SciFi", "Titanic_(1997_film)_poster.png", "Titanic is a 1997 American romantic disaster film directed, written, produced, and co-edited by James Cameron. Incorporating both historical and fictionalized aspects, it is based on accounts of the sinking of RMS Titanic in 1912.", "Titanic" },
                    { 5, "J. J. Abrams", "SciFi", "Star_Wars_The_Force_Awakens_Theatrical_Poster.jpg", "Star Wars: The Force Awakens (also known as Star Wars: Episode VII – The Force Awakens) is a 2015 American epic space opera film co-produced, co-written, and directed by J. J. Abrams. The sequel to Return of the Jedi (1983), it is the seventh film in the \"Skywalker Saga\". ", "Star Wars: The Force Awakens" },
                    { 6, "Russo Brothers", "SciFi", "Avengers_Infinity_War_poster.jpg", "Avengers: Infinity War is a 2018 American superhero film based on the Marvel Comics superhero team the Avengers.", "Avengers: Infinity War" },
                    { 7, "Jon Watts", "SciFi", "Spider-Man_No_Way_Home_poster.jpg", "Spider-Man: No Way Home is a 2021 American superhero film based on the Marvel Comics character Spider-Man, co-produced by Columbia Pictures and Marvel Studios, and distributed by Sony Pictures Releasing.", "Spider-Man: No Way Home" },
                    { 8, "Colin Trevorrow", "SciFi", "Jurassic_World_poster.jpg", "Jurassic World is a 2015 American science fiction action film directed by Colin Trevorrow, who co-wrote the screenplay with Rick Jaffa, Amanda Silver, and Derek Connolly from a story by Jaffa and Silver.", "Jurassic World" },
                    { 9, "Jon Favreau", "Fiction", "Disney_The_Lion_King_2019.jpg", "The Lion King is a 2019 American musical drama film directed by Jon Favreau, written by Jeff Nathanson, and produced by Walt Disney Pictures and Fairview Entertainment.", "The Lion King" },
                    { 10, "Joss Whedon", "SciFi", "The_Avengers_(2012_film)_poster.jpg", "Marvel's The Avengers[5] (classified under the name Marvel Avengers Assemble in the United Kingdom and Ireland),[1][6] or simply The Avengers, is a 2012 American superhero film based on the Marvel Comics superhero team of the same name.", "The Avengers" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rating_MovieId",
                table: "Rating",
                column: "MovieId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rating");

            migrationBuilder.DropTable(
                name: "Movies");
        }
    }
}
