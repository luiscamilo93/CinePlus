﻿using CinePlus.Models;

namespace CinePlus.ViewModels
{
    public class ShowMoviesViewModel
    {
        public int TotalPages { get; set; }

        public int CurrentPage {  get; set; }   

        public List<Movie> Movies { get; set; }
    }
}
