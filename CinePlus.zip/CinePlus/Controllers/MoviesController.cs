﻿using CinePlus.Models;
using CinePlus.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;


namespace CinePlus.Controllers
{
    public class MoviesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MoviesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string searchString, int currentPage)
        {
            _context.Database.Migrate();

            ShowMoviesViewModel viewModel = new ShowMoviesViewModel();

            try
            {
                int pageSize = 6;

                if (searchString != null)
                {
                    currentPage = 1;
                }

                List<Movie> movies = await _context.Movies
                                    .Include(x => x.Ratings)
                                    .OrderBy(x => x.Title)
                                    .ToListAsync();

                if (!String.IsNullOrEmpty(searchString))
                {
                    searchString = searchString.ToLower();

                    movies = movies.Where(s => s.Title.Contains(searchString, StringComparison.CurrentCultureIgnoreCase)
                                           || s.Genre.Contains(searchString, StringComparison.CurrentCultureIgnoreCase)).ToList();
                }


                var totalpages = (movies.Count / pageSize) + 1;

                if (currentPage > totalpages)
                {
                    currentPage = totalpages;
                }

                if (currentPage < 1)
                {
                    currentPage = 1;
                }

                //pagination logic 
                movies = movies.Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

                viewModel.CurrentPage = currentPage;
                viewModel.Movies = movies;
                viewModel.TotalPages = totalpages;
            }
            catch (Exception ex)
            {
            }

            return View(viewModel);

        }

        public async Task<ActionResult> Rate(int Id)
        {
            Movie? movie = await _context.Movies.Where(x => x.Id == Id).FirstOrDefaultAsync();
            return View(movie);
        }

        public async Task<ActionResult> Rated(Movie movie)
        {
            try
            {
                var searchMovie = await _context.Movies.Include(x => x.Ratings)
                    .Where(x => x.Id == movie.Id).FirstOrDefaultAsync();

                searchMovie.Ratings.Add(new Rating()
                {
                    Score = movie.Rate
                });

                await _context.SaveChangesAsync();
            }
            catch (Exception)
            {

            }
            //, new { currentPage = }
            return RedirectToAction("Index");
        }



        public async Task<IActionResult> Ranking()
        {
            List<DataPoint> dataPoints = new List<DataPoint>();

            var movies = await _context.Movies.Include(x => x.Ratings).Where(x => x.Ratings != null).ToListAsync();

            var topmovies = movies.OrderByDescending(x => x.Ratings?.Count).Take(5).ToList();

            foreach (var moving in topmovies)
            {
                dataPoints.Add(new DataPoint(moving.Title, moving.Ratings?.Count ?? 0));

            }

            ViewBag.DataPoints = JsonConvert.SerializeObject(dataPoints);

            return View();
        }
    }
}
