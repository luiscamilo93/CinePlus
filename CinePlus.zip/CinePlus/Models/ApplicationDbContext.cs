﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Reflection.Metadata;

namespace CinePlus.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Movie> Movies { get; set; }


        #region Required
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 1,    
                Title = "Avatar",
                Director = "James Cameron",
                Genre = "SciFi",
                Poster = "Avatar_(2009_film)_poster.jpg",
                Synopsis = "Avatar (marketed as James Cameron's Avatar) is a 2009 epic science fiction film directed, written, co-produced, and co-edited by James Cameron and starring Sam Worthington, Zoe Saldana, Stephen Lang, Michelle Rodriguez,[6] and Sigourney Weaver."
            });

            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 2,
                Title = "Avengers: Endgame",
                Director = "Russo Brothers",
                Genre = "SciFi",
                Poster = "Avengers_Endgame_poster.jpg",
                Synopsis = "Avengers: Endgame is a 2019 American superhero film based on the Marvel Comics superhero team the Avengers."
            });

            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 3,
                Title = "Avatar: The Way of Water",
                Director = "James Cameron",
                Genre = "SciFi",
                Poster = "Avatar_The_Way_of_Water_poster.jpg",
                Synopsis = "Avatar: The Way of Water is a 2022 American epic science fiction film co-produced and directed by James Cameron, who co-wrote the screenplay with Rick Jaffa and Amanda Silver from a story the trio wrote with Josh Friedman and Shane Salerno."
            });

            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 4,
                Title = "Titanic",
                Director = "James Cameron",
                Genre = "SciFi",
                Poster = "Titanic_(1997_film)_poster.png",
                Synopsis = "Titanic is a 1997 American romantic disaster film directed, written, produced, and co-edited by James Cameron. Incorporating both historical and fictionalized aspects, it is based on accounts of the sinking of RMS Titanic in 1912."
            });

            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 5,
                Title = "Star Wars: The Force Awakens",
                Director = "J. J. Abrams",
                Genre = "SciFi",
                Poster = "Star_Wars_The_Force_Awakens_Theatrical_Poster.jpg",
                Synopsis = "Star Wars: The Force Awakens (also known as Star Wars: Episode VII – The Force Awakens) is a 2015 American epic space opera film co-produced, co-written, and directed by J. J. Abrams. The sequel to Return of the Jedi (1983), it is the seventh film in the \"Skywalker Saga\". "
            });





            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 6,
                Title = "Avengers: Infinity War",
                Director = "Russo Brothers",
                Genre = "SciFi",
                Poster = "Avengers_Infinity_War_poster.jpg",
                Synopsis = "Avengers: Infinity War is a 2018 American superhero film based on the Marvel Comics superhero team the Avengers."
            });
            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 7,
                Title = "Spider-Man: No Way Home",
                Director = "Jon Watts",
                Genre = "SciFi",
                Poster = "Spider-Man_No_Way_Home_poster.jpg",
                Synopsis = "Spider-Man: No Way Home is a 2021 American superhero film based on the Marvel Comics character Spider-Man, co-produced by Columbia Pictures and Marvel Studios, and distributed by Sony Pictures Releasing."
            });
            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 8,
                Title = "Jurassic World",
                Director = "Colin Trevorrow",
                Genre = "SciFi",
                Poster = "Jurassic_World_poster.jpg",
                Synopsis = "Jurassic World is a 2015 American science fiction action film directed by Colin Trevorrow, who co-wrote the screenplay with Rick Jaffa, Amanda Silver, and Derek Connolly from a story by Jaffa and Silver."
            });
            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 9,
                Title = "The Lion King",
                Director = "Jon Favreau",
                Genre = "Fiction",
                Poster = "Disney_The_Lion_King_2019.jpg",
                Synopsis = "The Lion King is a 2019 American musical drama film directed by Jon Favreau, written by Jeff Nathanson, and produced by Walt Disney Pictures and Fairview Entertainment."
            });
            modelBuilder.Entity<Movie>().HasData(new Movie
            {
                Id = 10,
                Title = "The Avengers",
                Director = "Joss Whedon",
                Genre = "SciFi",
                Poster = "The_Avengers_(2012_film)_poster.jpg",
                Synopsis = "Marvel's The Avengers[5] (classified under the name Marvel Avengers Assemble in the United Kingdom and Ireland),[1][6] or simply The Avengers, is a 2012 American superhero film based on the Marvel Comics superhero team of the same name."
            });
          
        }
        #endregion

    }
}
