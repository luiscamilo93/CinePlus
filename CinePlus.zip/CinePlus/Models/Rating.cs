﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CinePlus.Models
{
    public class Rating
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }

        public int Score { get; set; }
    }
}
